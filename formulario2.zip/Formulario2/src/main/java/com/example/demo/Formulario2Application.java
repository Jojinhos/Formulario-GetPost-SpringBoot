package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Formulario2Application {

	public static void main(String[] args) {
		SpringApplication.run(Formulario2Application.class, args);
	}

}
