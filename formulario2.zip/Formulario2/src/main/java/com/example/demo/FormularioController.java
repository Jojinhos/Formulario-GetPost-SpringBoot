package com.example.demo;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@Controller
public class FormularioController{
	
	@GetMapping("/")
	public String mostrarFormulario() {
		return "formulario";
	}
	
	@GetMapping("/paso-get")
	public String recibirGet(
			@RequestParam(name = "texto", defaultValue = "") String texto,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model) {
		
		mostrarResultado(texto, request, response, model, "GET");
		
		return "resultado";
		
	}
	@PostMapping("/paso-post")
    public String recibirPost(
            @RequestParam(name = "texto", defaultValue = "") String texto,
            HttpServletRequest request,
            HttpServletResponse response,
            Model model) {

        mostrarResultado(texto, request, response, model, "POST");

        return "resultado";
    }
	
	private void mostrarResultado(
			String texto,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model,
			String metodo ) {
		model.addAttribute("texto", texto);
		model.addAttribute("metodo", metodo);
		
		model.addAttribute(
				"contentType",
				request.getContentType());
		
		model.addAttribute(
				"encoding",
				request.getCharacterEncoding());

		model.addAttribute(
			    "responseContentType",
			    response.getContentType()
			);

		model.addAttribute(
			    "responseEncoding",
			    response.getCharacterEncoding()
			);
		
		/*EN esta parte codificamos el URL*/
		String textoCodificado = URLEncoder.encode(texto, StandardCharsets.UTF_8);
		
		model.addAttribute("enlaceCodificado", "/paso-get?texto=" + textoCodificado);
	}
	
	
	
}